
function city() {
    alert("Loading weather report...")
}

function hide(){
    var bar = document.querySelector("#cookiebar")
    bar.remove();
}

function convertc(degree) {
    return Math.round((degree * 1.8) + 32);
}

function convertf(degree){
    return Math.round((degree-32)/1.8);
}

function convertTemp(element) {
    for(var i=1; i<9; i++) {
        var degree = document.querySelector("#temp" + i);
        var temp = parseInt(degree.innerText);
        if(element.value == "°C") {
            degree.innerText = convertf(temp);
        } else {
            degree.innerText = convertc(temp)
        }        
    }
}

    